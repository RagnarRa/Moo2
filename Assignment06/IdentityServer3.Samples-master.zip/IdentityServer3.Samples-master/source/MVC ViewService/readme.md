Sample showing how to use MVC views and controllers for IdentityServer views. 

Thanks to [Ed](https://github.com/EddyPPP) for contributing the code!
