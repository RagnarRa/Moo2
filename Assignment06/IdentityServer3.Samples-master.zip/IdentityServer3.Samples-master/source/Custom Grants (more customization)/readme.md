Sample to illustrate how add support for non-standard grant types at the token endpoint.
